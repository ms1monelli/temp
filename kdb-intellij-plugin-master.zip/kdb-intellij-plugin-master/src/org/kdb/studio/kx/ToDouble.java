package org.kdb.studio.kx;

public interface ToDouble {
    double toDouble();
}
