/*
 *  Package:        CTest1::Package2
 *
 *      CTest1::Package2
 */

/*   
 *  Topic:          Overview
 *  
 *      blah blah
 *  
 *  Topic:          More Stuff
 *  
 *       blah blah
 */   


/*
 *  Constants:      FunctionA Return Values
 *
 *      Aconstant1 - meaning 1
 *      Aconstant2 - meaning 2
 *      Aconstant3 - meaning 3
 *      Aconstant4 - meaning 4
 *      Aconstant5 - meaning 5
 */

/*
 *  Function:       FunctionA
 *
 *      CTest1::Package2::FunctionA
 *
 *  See also:
 *      <FunctionA Return Values>
 */
void 
FunctionA()
{
}


/*
 *  Function:       FunctionB
 *
 *      CTest1::Package2::FunctionB
 *
 */
void
FunctionB(int arg2, int arg2)
{
}


/*
    Constants:      FunctionB Return Values

        Bconstant1 - meaning 1
        Bconstant2 - meaning 2
        Bconstant3 - meaning 3
        Bconstant4 - meaning 4
        Bconstant5 - meaning 5
 */

