/*
 *  Package:        CTest1::Package3
 *
 *      CTest1::Package3
 */

/*   
 *  Topic:          Overview
 *  
 *      blah blah
 *  
 *  Topic:          More Stuff
 *  
 *       blah blah
 */   

/*
 *  Function:       FunctionA
 *
 *      CTest1::Package3::FunctionA
 *
 */
void FunctionA()
{
}


/*
 *  Function:       FunctionB
 *
 *      CTest1::Package3::FunctionB
 *
 */
void FunctionB(int arg3, int arg2)
{
}

