
/*
 *  Class: EmptyClass
 */
class EmptyClass {
        /*empty*/
};

typedef class TypedefClass {
        TypedefClass();
        ~TypedefClass();
} Typedef_t;

