
/*  Package:        ClassB

    Function:       FunctionE

        Class B::FunctionE

---------------------------------------------------------------------------*/

void 
FunctionE()
{
}
