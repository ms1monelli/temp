##################################################################################
#   Class:          PerlClassA::Child2
#
#       PerlClassA::Root
#

package PerlClassA::Child2;

use base 'PerlClassA::Parent';

#   
#   Topic:          Overview.
#   
#       blah blah
#   
#   Topic:          More Stuff
#   
#       blah blah


#
#   Function:       FunctionA
#
#       PerlClassA::Child2::FunctionA
#
sub FunctionA
{
}


#
#   Function:       FunctionB
#
#       PerlClassA::Child2::FunctionB
#
sub FunctionB #(arg1, arg2)
{
}
