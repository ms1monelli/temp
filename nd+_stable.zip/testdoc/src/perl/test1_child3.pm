##################################################################################
#   Class:          PerlClassA::Child3
#
#       PerlClassA::Root
#

package PerlClassA::Child3;

use base 'PerlClassA::Parent';

##################################################################################
#   
#   Topic:          Overview
#   
#       blah blah
#   
#   Topic:          More Stuff
#   
#       blah blah
#


##################################################################################
#
#   Function:       FunctionA
#
#       PerlClassA::Child3::FunctionA
#
sub FunctionA
{
}


##################################################################################
#
#   Function:       FunctionB
#
#       PerlClassA::Child3::FunctionB
#
sub FunctionB #(arg1, arg2)
{
}
