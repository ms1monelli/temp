##################################################################################
#   Class:          PerlClassA::Child4
#
#       PerlClassA::Root
#
# 
#   Source:
#       The following source was documenting using the 1.4+ javadoc style.
#
#(code)
##   Class:          PerlClassA::Child4
##
##       PerlClassA::Root
##
#
###################################################################################
##   
##   Topic:          Overview
##   
##       blah blah
##   
##   Topic:          More Stuff
##   
##       blah blah
##
#
#
###
##
##   PerlClassA::Child4::FunctionA
##
##   @param arg1     Argument 1
##   @param arg2     Argument 2
##
#sub FunctionA   #(arg1, arg2)
#{
#}
#
###
##   PerlClassA::Child4::FunctionB
##
##   @param arg1     Argument 1
##   @param arg2     Argument 2
##
#sub FunctionB       #(arg1, arg2)
#{
#}
#(end)
#

package PerlClassA::Child4;

use base 'PerlClassA::Parent';

##################################################################################
#   
#   Topic:          Overview
#   
#       blah blah
#   
#   Topic:          More Stuff
#   
#       blah blah
#


##
#
#   PerlClassA::Child4::FunctionA
#
#   @param arg1     Argument 1
#   @param arg2     Argument 2
#
sub FunctionA #(arg1, arg2)
{
}


##
#   PerlClassA::Child4::FunctionB
#
#   @param arg1     Argument 1
#   @param arg2     Argument 2
#
sub FunctionB #(arg1, arg2)
{
}
