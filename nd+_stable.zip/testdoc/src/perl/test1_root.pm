##################################################################################
#   Class:          PerlClassA::Parent
#
#       PerlClassA::Root
#

package PerlClassA::Parent;

use base 'PerlClassA';

#   
#   Topic:          Overview
#   
#       blah blah
#   
#   Topic:          More Stuff
#   
#       blah blah
#
##################################################################################

#
#   Function:       FunctionA
#
#       PerlClassA::Parent::FunctionA
#
##################################################################################
sub FunctionA
{
}

#
#   Function:       FunctionB
#
#       PerlClassA::Parent::FunctionB
#
##################################################################################
sub FunctionB
{
}


