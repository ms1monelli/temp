
Topic: readme
Here's some text

Another heading:
jhfhf
kjhdfh

asdas
(begin drawing)
XXX
(end drawing)

And a drawing:
kldsjfkljdasf
(begin drawing debug=1)

vertical dotted line...
|
|
|

Boxes
[][][][]

thick line
     8
====/======



:     ___________                     |
_____|           |__________-----dasfhf
                                      |
              ---^	 
             	/ \	 
---------+     <   >O
         |      \ /
         +---o---V
(end drawing)
asdas

And yet another:
(begin drawing scale=2)
This should be squareish
: +----+
: |    |
: |    | 
: +----+
(end drawing)
;jdgf
And another drawing:

(begin drawing)
              _   _   _   _   _   _      _   _ 
       Clk: _| |_| |_| |_| |_| |_| |..._| |_| |
            _____ _______ __________   __ ____
 Some_data: _____X_1234__X__________...__X_1a_
                     ^
                     |
                     +---kljjf;klasjdf
Test______

<--->
^
|
|
v
(end drawing)

text stuff:
fkjas;ljf;lakjdf;las

(begin drawing debug=0)
space here  and here
 |              |
 v              v
| :left aligned  |
+--left again    |
| :two    words: |
| right aligned: |
|       aligned: |
|butted up       |
|       butted up|
        |
|    centred     |
|   acentreda    |
| _under lined_  |
(end drawing)


end text